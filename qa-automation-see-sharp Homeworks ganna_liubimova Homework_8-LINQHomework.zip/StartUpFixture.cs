namespace LINQHomework;

[SetUpFixture]
public class StartUpFixture
{
    [OneTimeSetUp]
    public void SetUp() { }
    
    [OneTimeTearDown]
    public void TearDown() { }
}