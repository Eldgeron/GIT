namespace LINQHomework.Models;

public class Review
{
    public string Reviewer { get; set; }
    public double Rating { get; set; }
}