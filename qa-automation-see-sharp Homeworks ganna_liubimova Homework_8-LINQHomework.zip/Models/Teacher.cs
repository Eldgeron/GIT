namespace LINQHomework.Models;

public class Teacher
{
    public int Id { get; set; }
    public string Name { get; set; }
    public int Age { get; set; }
    public string Subject { get; set; }
    public int Experience { get; set; }
}